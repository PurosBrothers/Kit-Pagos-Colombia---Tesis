import * as crypto from "crypto";
import { WebhookVerifier } from "./WebhookVerifier";
import { Gateway } from "../value-objects/Gateway";

describe("WebhookVerifier", () => {
  const verifier = new WebhookVerifier();

  describe("verify()", () => {
    describe("Wompi", () => {
      const secret = "test_events_secret_wompi";
      const timestamp = 1602113476;
      const transactionId = "1292-1602113476-10985";
      const status = "APPROVED";

      const checksum = crypto
        .createHash("sha256")
        .update(`${transactionId}${status}${timestamp}${secret}`)
        .digest("hex");

      const payload = JSON.stringify({
        event: "transaction.updated",
        data: {
          transaction: { id: transactionId, status },
        },
        timestamp,
        signature: {
          properties: ["data.transaction.id", "data.transaction.status"],
          checksum,
        },
      });

      it("valida una firma correcta", () => {
        const headers = { "x-event-checksum": checksum };
        expect(verifier.verify(payload, headers, secret, Gateway.WOMPI)).toBe(true);
      });

      it("rechaza si el payload fue alterado", () => {
        const tampered = payload.replace("APPROVED", "DECLINED");
        const headers = { "x-event-checksum": checksum };
        expect(verifier.verify(tampered, headers, secret, Gateway.WOMPI)).toBe(false);
      });

      it("rechaza si la firma es incorrecta", () => {
        const headers = { "x-event-checksum": "invalidsignature123" };
        expect(verifier.verify(payload, headers, secret, Gateway.WOMPI)).toBe(false);
      });

      it("rechaza si la firma tiene la misma longitud pero difiere en un solo caracter", () => {
        const alteredChecksum = (checksum[0] === "a" ? "b" : "a") + checksum.slice(1);
        const headers = { "x-event-checksum": alteredChecksum };

        const result = verifier.verify(payload, headers, secret, Gateway.WOMPI);
        expect(result).toBe(false);
      });
    });

    describe("Rapyd", () => {
      // Rapyd adquirio PayU GPO el 14 mar 2025.
      // Algoritmo: Base64( HMAC-SHA256( url_path + salt + timestamp + access_key + secret_key + body ) )
      // Fuente: https://docs.rapyd.net/en/webhook-authentication.html
      // "url_path" es la URL COMPLETA configurada en el panel de Rapyd para el
      // webhook, no un path relativo (ver architecture-log.md, punto 16).
      const secretKey  = "rapyd_secret_key_test";
      const accessKey  = "rapyd_access_key_test";
      const salt       = "random_salt_abc123";
      const timestamp  = "1727001234";
      const webhookUrl = "https://comercio-ejemplo.com/webhooks/rapyd";

      const payload = JSON.stringify({
        id: "wh_e0afb507504b5eb901449993fadba20f",
        type: "PAYMENT_COMPLETED",
        data: {
          id: "payment_f5e668f17ecc4b83a4d10aaa68260862",
          status: "CLO",
          paid: true,
        },
      });

      const signature = crypto
        .createHmac("sha256", secretKey)
        .update(webhookUrl + salt + timestamp + accessKey + secretKey + payload)
        .digest("base64");

      it("valida una firma Rapyd correcta en el header signature", () => {
        const headers = {
          signature,
          access_key: accessKey,
          salt,
          timestamp,
          "x-webhook-url": webhookUrl,
        };
        expect(verifier.verify(payload, headers, secretKey, Gateway.RAPYD)).toBe(true);
      });

      it("rechaza si el body fue alterado", () => {
        const tampered = payload.replace("PAYMENT_COMPLETED", "PAYMENT_FAILED");
        const headers = {
          signature,
          access_key: accessKey,
          salt,
          timestamp,
          "x-webhook-url": webhookUrl,
        };
        expect(verifier.verify(tampered, headers, secretKey, Gateway.RAPYD)).toBe(false);
      });

      it("rechaza si el secret es incorrecto", () => {
        const headers = {
          signature,
          access_key: accessKey,
          salt,
          timestamp,
          "x-webhook-url": webhookUrl,
        };
        expect(verifier.verify(payload, headers, "wrong_secret", Gateway.RAPYD)).toBe(false);
      });

      it("rechaza si falta el header signature", () => {
        const headers = {
          access_key: accessKey,
          salt,
          timestamp,
          "x-webhook-url": webhookUrl,
        };
        expect(verifier.verify(payload, headers, secretKey, Gateway.RAPYD)).toBe(false);
      });
    });

    describe("Mercado Pago", () => {
      const secret = "mp_webhook_secret_test";
      const dataId = "12345678";
      const requestId = "req-uuid-001";
      const ts = "1702500000";

      const v1 = crypto
        .createHmac("sha256", secret)
        .update(`id:${dataId};request-id:${requestId};ts:${ts};`)
        .digest("hex");

      const payload = JSON.stringify({
        action: "payment.updated",
        data: { id: dataId },
      });

      it("valida un header x-signature correcto", () => {
        const headers = {
          "x-signature": `ts=${ts},v1=${v1}`,
          "x-request-id": requestId,
        };
        expect(verifier.verify(payload, headers, secret, Gateway.MERCADOPAGO)).toBe(true);
      });

      it("rechaza si el secret es incorrecto", () => {
        const headers = {
          "x-signature": `ts=${ts},v1=${v1}`,
          "x-request-id": requestId,
        };
        expect(verifier.verify(payload, headers, "wrong_secret", Gateway.MERCADOPAGO)).toBe(false);
      });
    });

    describe("Kushki", () => {
      const secret = "kushki_signature_id";
      const kushkiId = "1702500000";

      const payload = JSON.stringify({
        transaction_status: "APPROVAL",
        transaction_id: "781482485839103928",
      });

      const signature = crypto
        .createHmac("sha256", secret)
        .update(`${payload}.${kushkiId}`)
        .digest("hex");

      it("valida una firma HMAC correcta", () => {
        const headers = {
          "x-kushki-signature": signature,
          "x-kushki-id": kushkiId,
        };
        expect(verifier.verify(payload, headers, secret, Gateway.KUSHKI)).toBe(true);
      });

      it("rechaza si el body fue alterado", () => {
        const tampered = payload.replace("APPROVAL", "DECLINED");
        const headers = {
          "x-kushki-signature": signature,
          "x-kushki-id": kushkiId,
        };
        expect(verifier.verify(tampered, headers, secret, Gateway.KUSHKI)).toBe(false);
      });
    });
  });

  describe("parse()", () => {
    it("normaliza eventos de Wompi", () => {
      const payload = JSON.stringify({
        event: "transaction.updated",
        data: {
          transaction: { id: "wompi-tx-123", status: "APPROVED" },
        },
      });

      const event = verifier.parse(payload, Gateway.WOMPI);
      expect(event.eventType).toBe("transaction.updated");
      expect(event.gatewayTransactionId).toBe("wompi-tx-123");
      expect(event.newStatus).toBe("APPROVED");
      expect(event.gateway).toBe(Gateway.WOMPI);
    });

    it("normaliza eventos de Rapyd (PAYMENT_COMPLETED)", () => {
      const payload = JSON.stringify({
        id: "wh_e0afb507504b5eb901449993fadba20f",
        type: "PAYMENT_COMPLETED",
        data: { id: "payment_rapyd-tx-456", status: "CLO", paid: true },
      });

      const event = verifier.parse(payload, Gateway.RAPYD);
      expect(event.eventType).toBe("PAYMENT_COMPLETED");
      expect(event.gatewayTransactionId).toBe("payment_rapyd-tx-456");
      expect(event.newStatus).toBe("APPROVED");
      expect(event.gateway).toBe(Gateway.RAPYD);
    });

    it("normaliza eventos de Rapyd pendientes (PAYMENT_SUCCEEDED con data.status ACT)", () => {
      const payload = JSON.stringify({
        id: "wh_abc123",
        type: "PAYMENT_SUCCEEDED",
        data: { id: "payment_rapyd-tx-789", status: "ACT", paid: false },
      });

      const event = verifier.parse(payload, Gateway.RAPYD);
      expect(event.newStatus).toBe("PENDING");
    });

    it("normaliza eventos de Rapyd expirados (PAYMENT_EXPIRED)", () => {
      const payload = JSON.stringify({
        id: "wh_exp001",
        type: "PAYMENT_EXPIRED",
        data: { id: "payment_rapyd-tx-exp", status: "EXP" },
      });

      const event = verifier.parse(payload, Gateway.RAPYD);
      expect(event.newStatus).toBe("EXPIRED");
    });

    it("normaliza eventos de Rapyd cancelados (PAYMENT_CANCELED)", () => {
      const payload = JSON.stringify({
        id: "wh_can001",
        type: "PAYMENT_CANCELED",
        data: { id: "payment_rapyd-tx-can", status: "CAN" },
      });

      const event = verifier.parse(payload, Gateway.RAPYD);
      expect(event.newStatus).toBe("VOIDED");
    });

    it("normaliza eventos de Mercado Pago con estado en minuscula", () => {
      const payload = JSON.stringify({
        action: "payment.updated",
        data: { id: "mp-123" },
        status: "approved",
      });

      const event = verifier.parse(payload, Gateway.MERCADOPAGO);
      expect(event.eventType).toBe("payment.updated");
      expect(event.gatewayTransactionId).toBe("mp-123");
      expect(event.newStatus).toBe("APPROVED");
      expect(event.gateway).toBe(Gateway.MERCADOPAGO);
    });

    it("normaliza notificaciones nativas de Mercado Pago sin status a PENDING (flujo de 2 pasos)", () => {
      const payload = JSON.stringify({
        action: "payment.created",
        data: { id: "mp-native-999" },
      });

      const event = verifier.parse(payload, Gateway.MERCADOPAGO);
      expect(event.eventType).toBe("payment.created");
      expect(event.gatewayTransactionId).toBe("mp-native-999");
      expect(event.newStatus).toBe("PENDING");
      expect(event.gateway).toBe(Gateway.MERCADOPAGO);
    });

    it("extrae eventType desde type en Mercado Pago cuando action no está presente", () => {
      const payload = JSON.stringify({
        type: "payment",
        data: { id: "mp-type-888" },
      });

      const event = verifier.parse(payload, Gateway.MERCADOPAGO);
      expect(event.eventType).toBe("payment");
      expect(event.gatewayTransactionId).toBe("mp-type-888");
      expect(event.newStatus).toBe("PENDING");
      expect(event.gateway).toBe(Gateway.MERCADOPAGO);
    });

    it("normaliza eventos de Mercado Pago con in_process a PENDING y cancelled a VOIDED", () => {
      const payloadInProcess = JSON.stringify({
        action: "payment.updated",
        data: { id: "mp-proc-1" },
        status: "in_process",
      });
      const eventProc = verifier.parse(payloadInProcess, Gateway.MERCADOPAGO);
      expect(eventProc.newStatus).toBe("PENDING");

      const payloadCancelled = JSON.stringify({
        action: "payment.updated",
        data: { id: "mp-canc-2" },
        status: "cancelled",
      });
      const eventCanc = verifier.parse(payloadCancelled, Gateway.MERCADOPAGO);
      expect(eventCanc.newStatus).toBe("VOIDED");
    });

    it("normaliza eventos de Kushki con APPROVAL a APPROVED", () => {
      const payload = JSON.stringify({
        transaction_id: "kushki-tx-789",
        transaction_status: "APPROVAL",
      });

      const event = verifier.parse(payload, Gateway.KUSHKI);
      expect(event.eventType).toBe("transaction.updated");
      expect(event.gatewayTransactionId).toBe("kushki-tx-789");
      expect(event.newStatus).toBe("APPROVED");
      expect(event.gateway).toBe(Gateway.KUSHKI);
    });

    it("mapea estados de rechazo correctamente", () => {
      const wompiDeclined = JSON.stringify({
        data: { transaction: { id: "1", status: "DECLINED" } },
      });
      expect(verifier.parse(wompiDeclined, Gateway.WOMPI).newStatus).toBe("DECLINED");

      // Rapyd usa el prefijo de failure_code para distinguir un rechazo de
      // negocio (del procesador de tarjeta) de un fallo tecnico, ya que
      // data.status es "ERR" en ambos casos. Ver docs.rapyd.net/en/card-network-errors.html.
      const rapydCardDeclined = JSON.stringify({
        id: "wh_def456",
        type: "PAYMENT_FAILED",
        data: { id: "payment_2", status: "ERR", failure_code: "ERROR_PROCESSING_CARD - [51]" },
      });
      expect(verifier.parse(rapydCardDeclined, Gateway.RAPYD).newStatus).toBe("DECLINED");

      const rapydTechnicalError = JSON.stringify({
        id: "wh_def789",
        type: "PAYMENT_FAILED",
        data: { id: "payment_3", status: "ERR", failure_code: "MISSING_AUTHENTICATION_HEADERS" },
      });
      expect(verifier.parse(rapydTechnicalError, Gateway.RAPYD).newStatus).toBe("ERROR");

      const mpRejected = JSON.stringify({ data: { id: "3" }, status: "rejected" });
      expect(verifier.parse(mpRejected, Gateway.MERCADOPAGO).newStatus).toBe("DECLINED");

      const kushkiDeclined = JSON.stringify({ transaction_id: "4", transaction_status: "DECLINED" });
      expect(verifier.parse(kushkiDeclined, Gateway.KUSHKI).newStatus).toBe("DECLINED");
    });

    it("mapea estados adicionales como VOIDED, ERROR y PENDING", () => {
      const wompiVoided = JSON.stringify({
        data: { transaction: { id: "1", status: "VOIDED" } },
      });
      expect(verifier.parse(wompiVoided, Gateway.WOMPI).newStatus).toBe("VOIDED");

      const wompiError = JSON.stringify({
        data: { transaction: { id: "1", status: "ERROR" } },
      });
      expect(verifier.parse(wompiError, Gateway.WOMPI).newStatus).toBe("ERROR");

      const wompiUnknown = JSON.stringify({
        data: { transaction: { id: "1", status: "OTHER" } },
      });
      expect(verifier.parse(wompiUnknown, Gateway.WOMPI).newStatus).toBe("ERROR");

      const rapydUnknown = JSON.stringify({
        type: "OTHER_EVENT",
        data: { id: "payment_unk" },
      });
      expect(verifier.parse(rapydUnknown, Gateway.RAPYD).newStatus).toBe("ERROR");

      const mpPending = JSON.stringify({
        action: "payment.updated",
        data: { id: "mp-pend" },
        status: "pending",
      });
      expect(verifier.parse(mpPending, Gateway.MERCADOPAGO).newStatus).toBe("PENDING");

      const mpUnknown = JSON.stringify({
        action: "payment.updated",
        data: { id: "mp-unk" },
        status: "unknown_status",
      });
      expect(verifier.parse(mpUnknown, Gateway.MERCADOPAGO).newStatus).toBe("ERROR");

      const kushkiUnknown = JSON.stringify({
        transaction_id: "k-unk",
        transaction_status: "UNKNOWN",
      });
      expect(verifier.parse(kushkiUnknown, Gateway.KUSHKI).newStatus).toBe("ERROR");
    });

    it("lanza error si el gateway no es reconocido", () => {
      expect(() => verifier.parse("{}", "UNKNOWN_GW" as unknown as Gateway)).toThrow(
        "WebhookVerifier.parse: Gateway desconocido"
      );
      expect(() => verifier.verify("{}", {}, "secret", "UNKNOWN_GW" as unknown as Gateway)).toThrow(
        "WebhookVerifier.verify: Gateway desconocido"
      );
    });
  });
});
