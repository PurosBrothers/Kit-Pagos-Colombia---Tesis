import {
  PaymentGatewayPort,
  CreatePaymentRequest,
} from "../../application/ports/PaymentGatewayPort";
import { Transaction } from "../../domain/entities/Transaction";
import { Gateway } from "../../domain/value-objects/Gateway";
import { Credentials } from "../../domain/value-objects/Credentials";
import { ResponseNormalizer } from "../../application/services/ResponseNormalizer";
import { WebhookVerifier } from "../../domain/services/WebhookVerifier";
import { ErrorHandler } from "../../application/services/ErrorHandler";
import { TaxBreakdown } from "../../domain/value-objects/TaxBreakdown";

const DEFAULT_KUSHKI_BASE_URL =
  "http://localhost:3000/v1/sim/kushki/charges";

export class KushkiAdapter implements PaymentGatewayPort {
  private readonly baseUrl: string;
  private readonly credentials?: Credentials;
  private readonly normalizer: ResponseNormalizer;
  private readonly webhookVerifier: WebhookVerifier;

  constructor(
    baseUrl: string = DEFAULT_KUSHKI_BASE_URL,
    credentials?: Credentials,
    normalizer: ResponseNormalizer = new ResponseNormalizer(),
    webhookVerifier: WebhookVerifier = new WebhookVerifier(),
  ) {
    this.baseUrl = baseUrl;
    this.credentials = credentials;
    this.normalizer = normalizer;
    this.webhookVerifier = webhookVerifier;
  }

  async createPayment(request: CreatePaymentRequest): Promise<Transaction> {
    const total = request.amount.toMinorUnits(request.currency);

    /*
     * Kushki requires the amount to be split into subtotalIva0,
     * subtotalIva, iva and ice.
     *
     * The domain does not model Colombian tax rules yet, so when the
     * merchant does not provide a tax breakdown we deliberately treat
     * the complete amount as exempt.
     */
    const taxBreakdown =
        request.taxBreakdown ??
        TaxBreakdown.exempt(request.amount, request.currency);

        if (!taxBreakdown.getTotal().equals(request.amount)) {
            throw new Error(
                "Kushki tax breakdown does not match the payment amount",
        );
    }

    const payload = {
      token: "simulated-token",
      amount: {
            subtotalIva0: Number(
                taxBreakdown.subtotalIva0.toMinorUnits(request.currency),
            ),
            subtotalIva: Number(
                taxBreakdown.subtotalIva.toMinorUnits(request.currency),
            ),
            iva: Number(
                taxBreakdown.iva.toMinorUnits(request.currency),
            ),
            ice: Number(
                taxBreakdown.ice.toMinorUnits(request.currency),
            ),
            currency: request.currency.getCode(),
      },
      contactDetails: {
        email: request.payer.email,
      },
    };

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.credentials) {
      headers["Private-Merchant-Id"] = this.credentials.privateKey;
    }

    let response: Response;

    try {
      response = await fetch(this.baseUrl, {
        method: "POST",
        headers,
        body: JSON.stringify(payload),
      });
    } catch (networkError) {
      const errorHandler = new ErrorHandler();
      throw errorHandler.handle(networkError, Gateway.KUSHKI);
    }

    if (!response.ok) {
      let errorBody: unknown;

      try {
        errorBody = await response.json();
      } catch {
        errorBody = await response.text();
      }

      const errorHandler = new ErrorHandler();

      throw errorHandler.handle(
        {
          status: response.status,
          body: errorBody,
        },
        Gateway.KUSHKI,
      );
    }

    let rawResponse: unknown;

    try {
      rawResponse = await response.json();
    } catch (parseError) {
      const errorHandler = new ErrorHandler();
      throw errorHandler.handle(parseError, Gateway.KUSHKI);
    }

    return this.normalizer.normalize(rawResponse, Gateway.KUSHKI);
  }

  async getStatus(gatewayTransactionId: string): Promise<Transaction> {
    const statusUrl = `${this.baseUrl}/${gatewayTransactionId}`;

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.credentials) {
      headers["Private-Merchant-Id"] = this.credentials.privateKey;
    }

    let response: Response;

    try {
      response = await fetch(statusUrl, {
        method: "GET",
        headers,
      });
    } catch (networkError) {
      const errorHandler = new ErrorHandler();
      throw errorHandler.handle(networkError, Gateway.KUSHKI);
    }

    if (!response.ok) {
      let errorBody: unknown;

      try {
        errorBody = await response.json();
      } catch {
        errorBody = await response.text();
      }

      const errorHandler = new ErrorHandler();

      throw errorHandler.handle(
        {
          status: response.status,
          body: errorBody,
        },
        Gateway.KUSHKI,
      );
    }

    let rawResponse: unknown;

    try {
      rawResponse = await response.json();
    } catch (parseError) {
      const errorHandler = new ErrorHandler();
      throw errorHandler.handle(parseError, Gateway.KUSHKI);
    }

    return this.normalizer.normalize(rawResponse, Gateway.KUSHKI);
  }

  verifySignature(
    payload: string,
    headers: Record<string, string>,
    secret: string,
  ): boolean {
    return this.webhookVerifier.verify(
      payload,
      headers,
      secret,
      Gateway.KUSHKI,
    );
  }
}